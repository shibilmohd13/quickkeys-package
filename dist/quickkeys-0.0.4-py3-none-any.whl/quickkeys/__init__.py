from QuickOTP import *
from QuickPass import *